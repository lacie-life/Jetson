# Jetson Nano Developer Kit Regulatory and Compliance Documents

These regulatory documents are required for sale of Jetson Nano Developer Kit, and may be leveraged in some cases for products based on Jetson Nano.

| Country    | Regulatory Body |   Cert Type   |              Filename                |
|------------|-----------------|---------------|--------------------------------------|
| INT'L      | various         | Environmental | P3450_ENV.pdf                        |
| INT'L      | UL              | Safety        | P3450_UL_Cert.pdf                    |
| INT'L      | IEC             | Safety        | P3450_CB_Cert                        |
| Australia &| ACMA, RCM       | EMC/Radio     | P3450_AU_Cert.pdf                    |
| New Zealand|                 |               |                                      |
| Japan      | VCCI, MIC       | EMC/Radio     | P3450_Japan_Cert.pdf                 |
| EU         | EC              | EMC/Radio     | P3450_EU_Cert.pdf                    |
| US, Canada | FCC, ICES       | EMC/Radio     | P3450_US_CA_Cert.pdf                 |
| Korea      | RRA             | EMC/Radio     | P3450_KC_Cert.pdf                    |
| Taiwan     | BSMI, NCC       | EMC/Radio     | P3450_Taiwan_Cert.pdf                |
| Russia     | EAC             | EMC           | P3450_Russia_Cert.pdf                |
